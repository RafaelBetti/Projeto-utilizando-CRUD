SELECT * FROM public.gerenciamento;
SELECT * FROM empresas;
SELECT * FROM setores;

CREATE DATABASE athia;

\c gerenciamento

CREATE TABLE empresas (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(255) NOT NULL
);

CREATE TABLE setores (
  id SERIAL PRIMARY KEY,
  nome VARCHAR(255) NOT NULL
);

CREATE TABLE gerenciamento (
    empresa_id INT REFERENCES empresas(id) ON DELETE CASCADE,
    setor_id INT REFERENCES setores(id) ON DELETE CASCADE,
    PRIMARY KEY (empresa_id, setor_id)
);
