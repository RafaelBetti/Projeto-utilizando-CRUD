const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { Pool } = require('pg');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const pool = new Pool({
  user: 'postgres', 
  host: 'localhost',
  database: 'gerenciamento', 
  password: 'postgres123', 
  port: 5432, 
});

const handleError = (err, res) => {
  console.error('Erro:', err.message);
  res.status(500).json({ error: 'Erro no servidor. Tente novamente mais tarde.' });
};

app.get('/empresas', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM empresas');
    res.json(result.rows);
  } catch (err) {
    handleError(err, res);
  }
});

app.post('/empresas', async (req, res) => {
  const { nome } = req.body;
  if (!nome) {
    return res.status(400).json({ error: 'O campo nome é obrigatório.' });
  }
  try {
    const result = await pool.query(
      'INSERT INTO empresas (nome) VALUES ($1) RETURNING *',
      [nome]
    );
    res.json(result.rows[0]);
  } catch (err) {
    handleError(err, res);
  }
});

app.put('/empresas/:id', async (req, res) => {
  const { id } = req.params;
  const { nome } = req.body;
  if (!nome) {
    return res.status(400).json({ error: 'O campo nome é obrigatório.' });
  }
  try {
    const result = await pool.query(
      'UPDATE empresas SET nome = $1 WHERE id = $2 RETURNING *',
      [nome, id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Empresa não encontrada.' });
    }
    res.json(result.rows[0]);
  } catch (err) {
    handleError(err, res);
  }
});

app.delete('/empresas/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query('DELETE FROM empresas WHERE id = $1', [id]);
    if (result.rowCount === 0) {
      return res.status(404).json({ error: 'Empresa não encontrada.' });
    }
    res.json({ message: 'Empresa deletada com sucesso.' });
  } catch (err) {
    handleError(err, res);
  }
});

app.get('/setores', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM setores');
    res.json(result.rows);
  } catch (err) {
    handleError(err, res);
  }
});

app.post('/setores', async (req, res) => {
  const { nome } = req.body;
  if (!nome) {
    return res.status(400).json({ error: 'O campo nome é obrigatório.' });
  }
  try {
    const result = await pool.query(
      'INSERT INTO setores (nome) VALUES ($1) RETURNING *',
      [nome]
    );
    res.json(result.rows[0]);
  } catch (err) {
    handleError(err, res);
  }
});

app.put('/setores/:id', async (req, res) => {
  const { id } = req.params;
  const { nome } = req.body;
  if (!nome) {
    return res.status(400).json({ error: 'O campo nome é obrigatório.' });
  }
  try {
    const result = await pool.query(
      'UPDATE setores SET nome = $1 WHERE id = $2 RETURNING *',
      [nome, id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Setor não encontrado.' });
    }
    res.json(result.rows[0]);
  } catch (err) {
    handleError(err, res);
  }
});

app.delete('/setores/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query('DELETE FROM setores WHERE id = $1', [id]);
    if (result.rowCount === 0) {
      return res.status(404).json({ error: 'Setor não encontrado.' });
    }
    res.json({ message: 'Setor deletado com sucesso.' });
  } catch (err) {
    handleError(err, res);
  }
});

app.listen(5000, () => {
  console.log('Servidor rodando na porta 5000');
});

