const apiUrl = 'http://localhost:5000';

function mostrarTela(telaId) {
  const telas = document.querySelectorAll('.tela');
  telas.forEach(tela => tela.style.display = 'none');
  document.getElementById(telaId).style.display = 'block';
}

async function listarEmpresas() {
  const response = await fetch(`${apiUrl}/empresas`);
  const empresas = await response.json();
  const lista = document.getElementById('empresas-list');
  lista.innerHTML = '';
  empresas.forEach((empresa) => {
    const item = document.createElement('li');
    item.textContent = empresa.nome;
    lista.appendChild(item);
  });
}

async function adicionarEmpresa() {
  const nome = document.getElementById('empresa-nome').value;
  await fetch(`${apiUrl}/empresas`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ nome })
  });
  listarEmpresas();
}

async function listarSetores() {
  const response = await fetch(`${apiUrl}/setores`);
  const setores = await response.json();
  const lista = document.getElementById('setores-list');
  lista.innerHTML = '';
  setores.forEach((setor) => {
    const item = document.createElement('li');
    item.textContent = setor.nome;
    lista.appendChild(item);
  });
}

async function adicionarSetor() {
  const nome = document.getElementById('setor-nome').value;
  await fetch(`${apiUrl}/setores`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ nome })
  });
  listarSetores();
}

app.get('/relatorio', async (req, res) => {
  const { empresa, setor } = req.query;

  const query = `
    SELECT e.nome AS empresa, s.nome AS setor
    FROM empresas e
    CROSS JOIN setores s
    WHERE ($1 = '' OR LOWER(e.nome) LIKE $2)
      AND ($3 = '' OR LOWER(s.nome) LIKE $4)
  `;

  const valores = [
    empresa || '', `%${empresa || ''}%`,
    setor || '', `%${setor || ''}%`
  ];

  const result = await pool.query(query, valores);
  res.json(result.rows);
});

console.log('Empresas:', empresas);
console.log('Setores:', setores);
console.log('Tabela:', tabelaCorpo.innerHTML);


async function filtrarRelatorio() {
  const filtroEmpresa = document.getElementById('filtro-empresa').value.toLowerCase();
  const filtroSetor = document.getElementById('filtro-setor').value.toLowerCase();

  try {

    const empresas = await (await fetch(`${apiUrl}/empresas`)).json();
    const setores = await (await fetch(`${apiUrl}/setores`)).json();

    const tabelaCorpo = document.getElementById('relatorio-table-body');
    tabelaCorpo.innerHTML = ''; 

    let encontrouResultados = false;


    empresas.forEach((empresa) => {
      setores.forEach((setor) => {
        if (
          (filtroEmpresa === '' || empresa.nome.toLowerCase().includes(filtroEmpresa)) &&
          (filtroSetor === '' || setor.nome.toLowerCase().includes(filtroSetor))
        ) {
          encontrouResultados = true;


          const linha = document.createElement('tr');

          const celulaEmpresa = document.createElement('td');
          celulaEmpresa.textContent = empresa.nome;
          linha.appendChild(celulaEmpresa);

          const celulaSetor = document.createElement('td');
          celulaSetor.textContent = setor.nome;
          linha.appendChild(celulaSetor);

          tabelaCorpo.appendChild(linha);
        }
      });
    });


    if (!encontrouResultados) {
      const linha = document.createElement('tr');
      const celula = document.createElement('td');
      celula.setAttribute('colspan', '2');
      celula.textContent = 'Nenhum resultado encontrado.';
      linha.appendChild(celula);
      tabelaCorpo.appendChild(linha);
    }
  } catch (error) {
    console.error('Erro ao buscar dados:', error);
  }
}
